from flask import Flask, render_template, request, redirect, url_for, session
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key'

CREDENTIALS_FILE = 'credentials.json'
NOTES_FILE = 'notes.json'

def load_notes():
    with open(NOTES_FILE, 'r') as f:
        return json.load(f)

def save_notes(data):
    with open(NOTES_FILE, 'w') as f:
        json.dump(data, f)

def load_credentials():
    with open(CREDENTIALS_FILE, 'r') as f:
        return json.load(f)

def save_credentials(data):
    with open(CREDENTIALS_FILE, 'w') as f:
        json.dump(data, f)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        creds = load_credentials()
        if request.form['username'] == creds['username'] and request.form['password'] == creds['password']:
            session['logged_in'] = True
            return redirect(url_for('edit'))
        else:
            return render_template('login.html', error="Invalid Credentials")
    return render_template('login.html')

@app.route('/edit', methods=['GET', 'POST'])
def edit():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    notes = load_notes()
    if request.method == 'POST':
        notes['note1'] = request.form['note1']
        notes['note2'] = request.form['note2']
        notes['note3'] = request.form['note3']
        save_notes(notes)
    return render_template('edit_notes.html', notes=notes)

@app.route('/display')
def display():
    notes = load_notes()
    return render_template('display.html', notes=notes)

@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    if request.method == 'POST':
        new_username = request.form['new_username']
        new_password = request.form['new_password']
        save_credentials({"username": new_username, "password": new_password})
        return redirect(url_for('edit'))
    return render_template('change_password.html')

@app.route('/logout')
def logout():
    session['logged_in'] = False
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)